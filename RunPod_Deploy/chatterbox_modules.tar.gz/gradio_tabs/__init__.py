"""
ChatterboxTTS Gradio Tabs Package
Modular tab system for the web interface
"""

# Make this directory a Python package
__version__ = "1.0.0"